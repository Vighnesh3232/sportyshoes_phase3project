package com.Vighnesh.phase3;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BuyRepo extends JpaRepository<Buy, Integer>{

}
